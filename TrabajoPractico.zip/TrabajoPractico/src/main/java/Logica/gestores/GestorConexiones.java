package Logica.gestores;

public class GestorConexiones {

}
