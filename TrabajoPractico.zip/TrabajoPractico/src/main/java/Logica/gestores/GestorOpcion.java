package Logica.gestores;

public class GestorOpcion {

}
