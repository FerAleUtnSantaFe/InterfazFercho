package Logica.gestores;

public class GestorFactor {

}
