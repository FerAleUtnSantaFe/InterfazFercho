package Logica.gestores;

public class GestorBloque {

}
