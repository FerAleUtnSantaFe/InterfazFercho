package Logica.gestores;

public class GestorPregunta {

}
