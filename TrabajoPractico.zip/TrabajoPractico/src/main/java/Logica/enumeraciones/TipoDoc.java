package Logica.enumeraciones;

public enum TipoDoc {
	DNI, CUIT, CUIL
}
