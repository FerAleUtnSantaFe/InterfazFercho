package enumerations;

public enum EstadoCuestionario {
	Activo, EnProceso, Completo, SinContestar
}
