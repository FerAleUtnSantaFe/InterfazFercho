package enumerations;

public enum TipoDoc {
	DNI, CUIT, CUIL
}
