package enumerations;

public enum TipoRespuesta {
	MultipleOpcion, VerdaderoOFalso
}
