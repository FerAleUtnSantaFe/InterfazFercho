package enumerations;

public enum TipoCompetencia {
	Actitudinal, Tecnica
}
