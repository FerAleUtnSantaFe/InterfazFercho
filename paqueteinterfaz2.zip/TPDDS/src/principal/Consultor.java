package principal;


public class Consultor {
	public String usuario;
	public String contrasena;
}
