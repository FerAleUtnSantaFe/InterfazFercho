package principal;

public class Opcion {
	public Integer numero;
	public String descripcion;
	public String nombre;
}
