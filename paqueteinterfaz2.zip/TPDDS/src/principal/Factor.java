package principal;

public class Factor {
	public String nombre;
	public String descripcion;
	public Integer puntaje;
}
