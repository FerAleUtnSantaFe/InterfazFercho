package principal;

import java.util.Date;

import enumerations.TipoDoc;

public class Candidato {
	public Integer NroCandidato;
	public TipoDoc tipoDoc;
	public Integer documento;
	public String apellido;
	public String nombre;
	public Date fechaNacimiento;
	public String nacionalidad;
	public String escolaridad;
	public boolean eliminado;
	
}
