package principal;

import enumerations.TipoCompetencia;

public class Competencia {
	public Integer codigo;
	public String nombre;
	public String descripcion;
	public TipoCompetencia tipoCompetencia;
}
