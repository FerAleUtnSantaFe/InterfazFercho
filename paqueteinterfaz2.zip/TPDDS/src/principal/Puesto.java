package principal;

public class Puesto {
	public Integer codigo;
	public String nombre;
	public String descripcion;
	public String empresa;
}
