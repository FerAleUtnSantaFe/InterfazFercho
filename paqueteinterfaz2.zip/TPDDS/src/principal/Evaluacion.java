package principal;

import java.sql.Time;

public class Evaluacion {
	public Time fechaInicio;
	public Time fechaFinal;
	public Integer maximoCandidatos;
}
