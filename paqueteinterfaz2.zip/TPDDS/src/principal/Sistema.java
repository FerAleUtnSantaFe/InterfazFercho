package principal;

import java.sql.Time;

public class Sistema {
	public Integer cantPreguntas;
	public Time tiempoCuestionario;
	public String fuente;
	public Integer maxCuestionariosActivos;
}
