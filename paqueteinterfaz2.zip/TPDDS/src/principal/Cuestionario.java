package principal;

import java.sql.Time;

import enumerations.EstadoCuestionario;

public class Cuestionario {
	public String nombre;
	public Time tiempo;
	public EstadoCuestionario estado;
	public String clave;
}
