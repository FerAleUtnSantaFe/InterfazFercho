package relaciones;

import principal.Opcion;

public class OpcionCuestionario {
	public PreguntaCuestionario preguntaCuestionario;
	public Opcion opcion;
}
