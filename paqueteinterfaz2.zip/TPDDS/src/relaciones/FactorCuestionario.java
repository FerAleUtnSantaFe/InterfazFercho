package relaciones;

import principal.Factor;

public class FactorCuestionario {
	public Factor factor;
	public PreguntaCuestionario preguntaCuestionario;
}
