package relaciones;

import principal.Pregunta;

public class PreguntaCuestionario {
	public Pregunta pregunta;
	public FactorCuestionario factorCuestionario;
	public OpcionCuestionario opcionCuestionario;
	public Bloque bloque;
}
