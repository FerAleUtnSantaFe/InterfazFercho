package relaciones;

import principal.Cuestionario;

public class Bloque {
	public Cuestionario cuestionario;
	public PreguntaCuestionario preguntaCuestionario;
}
