package relaciones;

public class PonderacionCompetencia {
	public Integer ponderacion;

}
