package relaciones;

import java.sql.Time;
import java.util.Date;

import principal.Candidato;
import principal.Cuestionario;

public class Realiza {
	public Cuestionario cuestionario;
	public Candidato candidato;
	public Date fechaInicio;
	public Date fechaFinal;
	public Time horaInicio;
	public Time horaFinal;
	public Integer puntajeObtenido;
}
