package gestores;

public class GestorCandidatos {

}
