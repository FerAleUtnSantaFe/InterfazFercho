package gestores;

public class GestorConsultor {

}
