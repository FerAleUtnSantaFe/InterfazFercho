package gestores;

public class GestorPuesto {

}
