package gestores;

public class GestorPregunta {

}
