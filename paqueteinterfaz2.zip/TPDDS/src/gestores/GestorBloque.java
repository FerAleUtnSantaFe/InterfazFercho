package gestores;

public class GestorBloque {

}
