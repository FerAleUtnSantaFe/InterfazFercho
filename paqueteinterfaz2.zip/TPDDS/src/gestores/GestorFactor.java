package gestores;

public class GestorFactor {

}
